//
//  ViewController.swift
//  week1_assignment
//
//  Created by 장서현 on 2020/10/16.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

