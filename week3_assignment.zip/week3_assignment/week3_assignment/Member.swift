//
//  Member.swift
//  week3_assignment
//
//  Created by 장서현 on 2020/11/06.
//

import UIKit

struct Member {
    var name: String
    var tag: String
    var memberImageName: String
    
    func makeMemberImage() -> UIImage? {
        return UIImage(named: memberImageName)
    }
}
