//
//  MemberCell.swift
//  week3_assignment
//
//  Created by 장서현 on 2020/11/06.
//

import UIKit

class MemberCell: UICollectionViewCell {
    static let identifier = "MemberCell"
    
    @IBOutlet weak var memberImage: UIImageView!
    @IBOutlet weak var memberName: UILabel!
    @IBOutlet weak var memberTag: UILabel!
    
    func setMember(member: Member){
        memberImage.image = member.makeMemberImage()
        memberName.text = member.name
        memberTag.text = member.tag
    }
}
