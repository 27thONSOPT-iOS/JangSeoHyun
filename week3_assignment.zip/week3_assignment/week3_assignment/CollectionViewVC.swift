//
//  CollectionViewVC.swift
//  week3_assignment
//
//  Created by 장서현 on 2020/11/06.
//

import UIKit

class CollectionViewVC: UIViewController {

    @IBOutlet weak var memberCollectionView: UICollectionView!
    
    var members: [Member] = []
        //[String] = ["juhyeok", "nayeon", "peace", "heesoo", "saeeun", "wool", "hansol", "minju", "younghun", "minguru", "yeonjeong", "junyeop"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setMemberData()
        memberCollectionView.delegate = self
        memberCollectionView.dataSource = self
        
        // Do any additional setup after loading the view.
    }
    func setMemberData() {
        members.append(contentsOf: [
            Member(name: "이주혁", tag: "#hereis#아요#내꿈은\n#사과농장#ENFP", memberImageName: "juhyeok"),
            Member(name: "김나연", tag: "#이제막학기 #여러분들이랑_친해지고_싶어요 #번개스터디환영", memberImageName: "nayeon"),
            Member(name: "손평화", tag: "#핸드피쓰 #이너피쓰 #배꼽도둑 #헬린이 #sson_peace7", memberImageName: "peace"),
            Member(name: "유희수", tag: "#총무꿈나무 #유총무 #현재_소식중 #풉", memberImageName: "heesoo"),
            Member(name: "박세은", tag: "#마 #아요는 #처음입니다", memberImageName: "saeeun"),
            Member(name: "한울", tag: "#ENFP #STORM #울크박스 #@hwooolll #하늘콜렉터", memberImageName: "wool"),
            Member(name: "김한솔", tag: "#고객중심#고객행동데이터기반한#UX디자이너#워너비,,", memberImageName: "hansol"),
            Member(name: "배민주", tag: "#디팟장 #개자이너 #최종목표는행복", memberImageName: "minju"),
            Member(name: "최영훈", tag: "#서팟짱 #솝트3회차 #앱잼_요리_개발자 #UX/UI", memberImageName: "younghun"),
            Member(name: "강민구", tag: "#밍맹 #안팟장 #이래뵈도_귀여운거좋아함 #지박령 #허당", memberImageName: "minguru"),
            Member(name: "이정연", tag: "#플레이스픽 #ENFJ #기획_디자인_개발_다", memberImageName: "yeonjeong"),
            Member(name: "홍준엽", tag: "#26기서버 #27기웹 #샵이_두개면_어떻게될까? ##", memberImageName: "junyeop")
        ])
    }
}

extension CollectionViewVC: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return members.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard  let cell = collectionView.dequeueReusableCell(withReuseIdentifier: MemberCell.identifier, for: indexPath) as? MemberCell else {
            return UICollectionViewCell()
        }
        cell.setMember(member: members[indexPath.item])
        return cell
    }
}

extension CollectionViewVC: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width,height: collectionView.frame.height)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 27
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    }
}
